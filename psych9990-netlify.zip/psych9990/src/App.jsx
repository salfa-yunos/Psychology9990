import { useState, useEffect, useRef } from "react";

// ═══════════════════════════════════════════════════
// CONFIGURATION — change ACCESS_CODE to your class password
// ═══════════════════════════════════════════════════
const ACCESS_CODE = "psych2026";

const EXAM_SECS = 5400;

const TOPIC_DATA = [
  { name: "Baron-Cohen et al. (Eyes Test)", pct: 96, approach: "Cognitive", tip: "3 groups: autism (n=16, 13M 3F), Tourette's (n=12), neurotypicals (n=50 Cambridge Library). Mean scores: autism 16.3 vs controls 20.3 out of 25." },
  { name: "Bandura et al. (Bobo Doll)", pct: 94, approach: "Learning", tip: "72 children (36M 36F). 3 conditions. Boys 38.2 physical acts vs girls 12.7. Know all 5 specific imitated behaviours." },
  { name: "Piliavin et al. (Subway Samaritans)", pct: 92, approach: "Social", tip: "95% helped ill victim vs ~50% drunk. Field experiment on NYC subway. No diffusion of responsibility found. ~4,450 passengers observed." },
  { name: "Ethics in Psychological Research", pct: 89, approach: "Issues & Debates", tip: "Link BPS guidelines to specific studies: harm/consent (Bandura), deception (Piliavin), right to withdraw. Almost always appears on Paper 1." },
  { name: "Research Methods (Validity & Reliability)", pct: 87, approach: "Methodology", tip: "Know all types: ecological, internal, concurrent, face validity. Apply to specific core studies. Always tested in Section A." },
  { name: "Hölzel et al. (Mindfulness & Brain Scans)", pct: 80, approach: "Biological", tip: "8-week MBSR programme. MRI before/after. Waitlist control (n=17). Grey matter increased in hippocampus, posterior cingulate cortex, temporoparietal junction." },
  { name: "Nature vs Nurture Debate", pct: 75, approach: "Issues & Debates", tip: "Contrast biological (Hölzel, Hassett) vs learning approach (Bandura, Fagen). Interactionist position scores highest marks." },
  { name: "Perry et al. (Personal Space)", pct: 72, approach: "Social", tip: "Observations in library vs gas station. Personal space larger in formal settings. Cultural and individual differences noted." },
  { name: "Fagen et al. (Elephant Learning)", pct: 68, approach: "Learning", tip: "Philadelphia Zoo. Elephant Mathilda trained via operant conditioning. Positive reinforcement (food). Foot care training." },
  { name: "Hassett et al. (Monkey Toy Preferences)", pct: 62, approach: "Biological", tip: "135 rhesus monkeys. Males strongly preferred wheeled toys. Females showed equal preference. Supports biological sex differences." },
  { name: "Pozzulo et al. (Police Line-Ups)", pct: 58, approach: "Cognitive", tip: "60 adults vs 60 children (7–9 yrs). Children made significantly more false positive identifications. Show-up vs sequential vs simultaneous." },
  { name: "Individual vs Situational Explanations", pct: 55, approach: "Issues & Debates", tip: "Social approach: bystander effect (Piliavin), situational norms (Perry). Contrast with dispositional/biological approach." },
];

const QUESTIONS = [
  { id:"q1", sec:"A", n:1, pts:2, type:"short", study:"Piliavin et al.",
    q:"Identify the research method used in the study by Piliavin et al. (subway Samaritans). State one advantage of using this research method in this study.",
    ph:"Research method: ...\n\nOne advantage of this method in this study: ...",
    hint:"1 mark for identifying the method; 1 mark for a contextualised advantage specific to this study" },
  { id:"q2", sec:"A", n:2, pts:4, type:"short", study:"Baron-Cohen et al.",
    q:"Describe the sample used in the study by Baron-Cohen et al. (eyes test). In your answer, refer to all groups included in the study.",
    ph:"The sample consisted of three groups:\n\nGroup 1 (autism/Asperger's): n = ..., sex ratio ...\n\nGroup 2 (Tourette's syndrome): n = ...\n\nGroup 3 (neurotypical controls): n = ..., recruited from ...",
    hint:"4 marks: describe all 3 groups with detail. 1 mark per accurate point." },
  { id:"q3", sec:"A", n:3, pts:4, type:"short", study:"Bandura et al.",
    q:"Using the study by Bandura et al. (1961), explain what is meant by 'social learning theory'. Your answer must include specific reference to the study's findings.",
    ph:"Social learning theory proposes that behaviour is learned through...\n\nIn Bandura et al., this was demonstrated when children in the aggressive condition...",
    hint:"2 marks for defining SLT; 2 marks for applying to specific findings from Bandura et al." },
  { id:"q4", sec:"A", n:4, pts:2, type:"short", study:"Bandura et al.",
    q:"Identify two ethical issues that arose in the study by Bandura et al. (1961).",
    ph:"Ethical issue 1: ...\n\nEthical issue 2: ...",
    hint:"1 mark per valid ethical issue correctly identified" },
  { id:"q5", sec:"A", n:5, pts:4, type:"short", study:"Hölzel et al.",
    q:"Describe the procedure of the study by Hölzel et al. (mindfulness and brain scans).",
    ph:"Participants were...\n\nThey completed an 8-week... programme.\n\nBrain scans (MRI) were taken...\n\nThis was compared with a control group who...",
    hint:"4 marks: 1 each for participant details, MBSR programme, MRI procedure, control group comparison" },
  { id:"q6", sec:"A", n:6, pts:6, type:"extended", study:"Piliavin et al.",
    q:"Describe the results of the study by Piliavin et al. (subway Samaritans). In your answer, refer to specific findings from the study.",
    ph:"The results of Piliavin et al. showed that...",
    hint:"Level-marked (1–6). Level 3 (5–6): accurate, detailed, multiple specific findings including statistics." },
  { id:"q7", sec:"A", n:7, pts:4, type:"short", study:"Biological & Cognitive approaches",
    q:"Explain one similarity and one difference between the biological approach and the cognitive approach. Refer to evidence from the core studies in your answer.",
    ph:"Similarity: Both the biological and cognitive approaches...\nEvidence: [study name] shows this because...\n\nDifference: The biological approach... whereas the cognitive approach...\nEvidence: [study] compared with [study]...",
    hint:"2 marks for similarity (point + named study evidence); 2 marks for difference (point + named study evidence)" },
  { id:"q8", sec:"A", n:8, pts:6, type:"extended", study:"Baron-Cohen et al.",
    q:"Explain two issues and debates relevant to the study by Baron-Cohen et al. (eyes test). In your answer, refer to the named study in detail.",
    ph:"Issue/Debate 1: [Name]\nApplication to Baron-Cohen et al.: ...\n\nIssue/Debate 2: [Name]\nApplication to Baron-Cohen et al.: ...",
    hint:"Level-marked (1–6). Evaluation NOT contextualised to Baron-Cohen et al. = Level 2 maximum." },
  { id:"q9", sec:"A", n:9, pts:6, type:"extended", study:"Fagen et al.",
    q:"Using the study by Fagen et al. (elephant learning), explain how the learning approach accounts for behaviour.",
    ph:"The learning approach assumes that behaviour is acquired through experience...\n\nFagen et al. supports this because...",
    hint:"Level-marked (1–6). Explain core assumptions of the learning approach AND apply specifically to Fagen et al." },
  { id:"q10", sec:"B", n:10, pts:12, type:"essay", study:"Bandura et al. + Baron-Cohen et al.",
    q:"Compare the study by Bandura et al. (1961) with the study by Baron-Cohen et al. (1997). In your answer, evaluate the research methods used in each study. Include at least one similarity and one difference in your comparison.",
    ph:"Overview of both studies:\n\nResearch methods in Bandura et al.:\n\nResearch methods in Baron-Cohen et al.:\n\nSimilarity:\n\nDifference:\n\nEvaluation of methods:",
    hint:"Level-marked (1–12). Evaluate research methods of BOTH studies. Level 5 (11–12) = comprehensive and balanced." },
  { id:"q11", sec:"B", n:11, pts:10, type:"essay", study:"Piliavin et al.",
    q:"Evaluate the study by Piliavin et al. (subway Samaritans) in terms of two strengths and two weaknesses. In your answer, refer to specific evidence from the study to support each evaluative point.",
    ph:"Strength 1:\nEvidence: ...\n\nStrength 2:\nEvidence: ...\n\nWeakness 1:\nEvidence: ...\n\nWeakness 2:\nEvidence: ...",
    hint:"Level-marked (1–10). All 4 points MUST be contextualised with specific evidence from Piliavin et al." },
];

function buildPrompt(answers) {
  const qa = QUESTIONS.map(q => {
    const ans = (answers[q.id] || "").trim();
    return `Question ${q.n} [${q.pts} marks – ${q.study}]:\n${q.q}\nSTUDENT ANSWER:\n${ans || "[NO ANSWER PROVIDED]"}`;
  }).join("\n\n---\n\n");

  return `You are a Cambridge International A Level Psychology (9990) chief examiner marking Paper 1 – Approaches, Issues and Debates (60 marks).

MARKING PRINCIPLES:
• AO1 = accurate psychological knowledge; AO2 = application; AO3 = contextualised evaluation
• For level-marked questions: evaluation NOT contextualised to the named study = Level 2 MAXIMUM
• Short-answer (2–4 marks): award per correct mark point; accept valid alternatives
• Blank/no answer = 0 marks always

KEY STUDY FACTS:
PILIAVIN et al.: NYC IRT subway field experiment; ~4,450 passengers; confederate collapsed (cane=ill OR drunk); 95% helped ill victim within 70s; ~50% helped drunk; NO diffusion of responsibility found; same-race helping tendency; 4 male confederates played victim, 6 female observers recorded
BARON-COHEN et al.: Group 1 = autism/Asperger's (n=16, 13M 3F); Group 2 = Tourette's (n=12, 6M 6F); Group 3 = neurotypical controls (n=50, 25M 25F, Cambridge Public Library); 25 greyscale eye photos, 4 options each; autism mean=16.3 vs controls 20.3; Tourette's=20.4
BANDURA et al.: 72 nursery children (36M 36F, ~52 months); 3 conditions + control; 5 specific aggressive acts; boys 38.2 physical acts vs girls 12.7; verbal: girls 79.5 vs boys 68.0
HÖLZEL et al.: 16 participants; 8-week MBSR programme; MRI before/after; waitlist control n=17; grey matter increased in hippocampus, posterior cingulate cortex, temporoparietal junction, cerebellum
FAGEN et al.: Philadelphia Zoo; elephant Mathilda; operant conditioning; positive reinforcement (food); foot care training
HASSETT et al.: 135 rhesus monkeys; males preferred wheeled toys significantly; females equal preference; supports biological sex differences
GRADE BOUNDARIES: A=45+ B=38-44 C=31-37 D=24-30 E=17-23 U=0-16

STUDENT ANSWERS:
${qa}

Return ONLY a raw JSON object (no markdown, no code fences, no preamble):
{
  "totalMarks": <integer 0-60>,
  "grade": "<A|B|C|D|E|U>",
  "gradeLabel": "<e.g. 'Grade A – Excellent'>",
  "overallComment": "<2-3 sentences specific to this student>",
  "strengths": ["<strength 1>", "<strength 2>", "<strength 3>"],
  "areasToImprove": ["<area 1>", "<area 2>", "<area 3>"],
  "examTip": "<single most impactful tip for this student>",
  "questions": [
    { "id": "q1", "marksGiven": <int>, "maxMarks": 2, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q2", "marksGiven": <int>, "maxMarks": 4, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q3", "marksGiven": <int>, "maxMarks": 4, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q4", "marksGiven": <int>, "maxMarks": 2, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q5", "marksGiven": <int>, "maxMarks": 4, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q6", "marksGiven": <int>, "maxMarks": 6, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q7", "marksGiven": <int>, "maxMarks": 4, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q8", "marksGiven": <int>, "maxMarks": 6, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q9", "marksGiven": <int>, "maxMarks": 6, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q10", "marksGiven": <int>, "maxMarks": 12, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" },
    { "id": "q11", "marksGiven": <int>, "maxMarks": 10, "whatWorked": "<str>", "gaps": "<str>", "modelAnswer": "<str>", "aoBreakdown": "<str>", "tip": "<str>" }
  ]
}`;
}

// ══════════════════ STYLE TOKENS ═══════════════════
const S = {
  darkBg:"#070F1E", card:"#0D1F3C", border:"#1E3A6A",
  gold:"#C8A84B", blue:"#3B82F6", purple:"#8B5CF6",
  green:"#10B981", orange:"#F59E0B", red:"#EF4444",
  cream:"#EDE5D0", muted:"#7A90B0",
  examBg:"#F5F0E6", examText:"#1A1F2E", examBorder:"#C9B99A",
};
const AC = { Cognitive:"#8B5CF6", Learning:"#3B82F6", Social:"#10B981", Biological:"#EF4444", "Issues & Debates":"#F59E0B", Methodology:"#06B6D4" };

// ══════════════════ ACCESS GATE ═════════════════════
function AccessGate({ onUnlock }) {
  const [code, setCode] = useState('');
  const [shake, setShake] = useState(false);

  const attempt = () => {
    if (code.toLowerCase().trim() === ACCESS_CODE.toLowerCase()) {
      onUnlock();
    } else {
      setShake(true);
      setCode('');
      setTimeout(() => setShake(false), 600);
    }
  };

  return (
    <div style={{ minHeight:"100vh", background:S.darkBg, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"system-ui" }}>
      <div style={{ textAlign:"center", color:S.cream, maxWidth:380, padding:32 }}>
        <div style={{ fontSize:56, marginBottom:20 }}>🔒</div>
        <h1 style={{ fontFamily:"Georgia,serif", fontSize:26, marginBottom:8 }}>Psychology 9990</h1>
        <p style={{ color:S.muted, fontSize:14, marginBottom:32 }}>Cambridge A Level Mock Examination<br/>Enter the class access code to continue</p>
        <div style={{ animation: shake ? "shake 0.4s" : "none" }}>
          <input
            value={code}
            onChange={e => setCode(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && attempt()}
            placeholder="Enter access code"
            type="password"
            style={{ width:"100%", boxSizing:"border-box", padding:"14px 18px", borderRadius:10, border:`2px solid ${S.border}`, background:"#0D1F3C", color:S.cream, fontSize:16, textAlign:"center", outline:"none", marginBottom:12, letterSpacing:3 }}
          />
          <button
            onClick={attempt}
            style={{ width:"100%", padding:"14px", background:`linear-gradient(135deg,${S.gold},#9A7A2D)`, color:"#000", border:"none", borderRadius:10, fontSize:16, fontWeight:700, cursor:"pointer" }}>
            Enter Exam →
          </button>
        </div>
        <p style={{ color:S.muted, fontSize:12, marginTop:24 }}>Ask your teacher for the access code</p>
      </div>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`}</style>
    </div>
  );
}

// ══════════════════ RESEARCH PAGE ═══════════════════
function Research({ onNext }) {
  const [hov, setHov] = useState(null);
  return (
    <div style={{ minHeight:"100vh", background:S.darkBg, color:S.cream, fontFamily:"Georgia,'Times New Roman',serif" }}>
      <div style={{ background:"linear-gradient(135deg,#0D1F3C 0%,#18083C 100%)", padding:"40px 32px 32px", borderBottom:`1px solid ${S.border}` }}>
        <div style={{ maxWidth:860, margin:"0 auto" }}>
          <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:10 }}>
            <span style={{ background:S.gold, color:"#000", padding:"3px 10px", borderRadius:4, fontSize:11, fontWeight:700, fontFamily:"system-ui", letterSpacing:1 }}>CAMBRIDGE 9990</span>
            <span style={{ color:S.muted, fontSize:13, fontFamily:"system-ui" }}>AS & A Level Psychology</span>
          </div>
          <h1 style={{ fontSize:32, fontWeight:700, margin:"0 0 8px", lineHeight:1.2 }}>Mock Examination — Intelligence Hub</h1>
          <p style={{ color:S.muted, margin:0, fontSize:14, fontFamily:"system-ui" }}>Evidence-based topic frequency analysis · Full Paper 1 simulation · Cambridge AI marking</p>
        </div>
      </div>
      <div style={{ maxWidth:860, margin:"0 auto", padding:"32px 24px" }}>
        <h2 style={{ fontFamily:"system-ui", fontSize:14, fontWeight:700, color:S.gold, letterSpacing:1, marginBottom:14 }}>PAPER 1 STRUCTURE</h2>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14, marginBottom:36 }}>
          {[
            { icon:"⏱️", label:"Duration", value:"90 Minutes", sub:"Strict timed condition" },
            { icon:"📊", label:"Total Marks", value:"60 Marks", sub:"25% of Full A Level" },
            { icon:"📝", label:"Questions", value:"11 Questions", sub:"Section A: 38 + Section B: 22" },
          ].map(c => (
            <div key={c.label} style={{ background:S.card, border:`1px solid ${S.border}`, borderRadius:12, padding:20 }}>
              <div style={{ fontSize:24, marginBottom:10 }}>{c.icon}</div>
              <div style={{ fontSize:22, fontWeight:700, color:S.gold, fontFamily:"system-ui" }}>{c.value}</div>
              <div style={{ fontSize:13, color:S.cream, fontFamily:"system-ui", fontWeight:600, marginTop:4 }}>{c.label}</div>
              <div style={{ fontSize:12, color:S.muted, fontFamily:"system-ui", marginTop:4 }}>{c.sub}</div>
            </div>
          ))}
        </div>

        <h2 style={{ fontFamily:"system-ui", fontSize:14, fontWeight:700, color:S.gold, letterSpacing:1, marginBottom:6 }}>TOPIC FREQUENCY ANALYSIS</h2>
        <p style={{ fontFamily:"system-ui", fontSize:13, color:S.muted, marginBottom:16 }}>Based on Cambridge 9990 past paper analysis (2018–2024). Hover each topic for an exam tip.</p>
        <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:36 }}>
          {TOPIC_DATA.map((t,i) => {
            const col = AC[t.approach] || S.blue;
            const isH = hov === i;
            return (
              <div key={t.name} onMouseEnter={() => setHov(i)} onMouseLeave={() => setHov(null)}
                style={{ background:isH?"#1A2F50":S.card, border:`1px solid ${isH?col:S.border}`, borderRadius:10, padding:"13px 18px", cursor:"default", transition:"all 0.15s" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{ width:40, textAlign:"right", color:col, fontWeight:700, fontFamily:"system-ui", fontSize:14, flexShrink:0 }}>{t.pct}%</div>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                      <span style={{ fontSize:14, fontWeight:600 }}>{t.name}</span>
                      {t.pct >= 88 && <span style={{ background:"#7F1D1D", color:"#FCA5A5", padding:"1px 8px", borderRadius:12, fontSize:10, fontFamily:"system-ui", fontWeight:700 }}>🔥 HIGH FREQ</span>}
                    </div>
                    <div style={{ background:"#0A1628", borderRadius:4, height:5, overflow:"hidden" }}>
                      <div style={{ width:`${t.pct}%`, height:"100%", background:col, borderRadius:4 }} />
                    </div>
                  </div>
                  <span style={{ background:col+"22", color:col, padding:"2px 10px", borderRadius:12, fontSize:11, fontFamily:"system-ui", fontWeight:600, flexShrink:0, whiteSpace:"nowrap" }}>{t.approach}</span>
                </div>
                {isH && (
                  <div style={{ marginLeft:52, marginTop:10, paddingTop:10, borderTop:`1px solid ${S.border}`, fontFamily:"system-ui", fontSize:12, color:S.cream, lineHeight:1.6 }}>
                    💡 <strong style={{ color:col }}>Exam tip:</strong> {t.tip}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <h2 style={{ fontFamily:"system-ui", fontSize:14, fontWeight:700, color:S.gold, letterSpacing:1, marginBottom:14 }}>ASSESSMENT OBJECTIVES</h2>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14, marginBottom:36 }}>
          {[
            { ao:"AO1", name:"Knowledge & Understanding", desc:"Accurate, relevant psychological knowledge of studies, theories and approaches", col:S.blue },
            { ao:"AO2", name:"Application", desc:"Apply knowledge to specific studies, scenarios and real-world contexts", col:S.green },
            { ao:"AO3", name:"Analysis & Evaluation", desc:"Critical evaluation contextualised to the named study — generic points earn partial credit only", col:S.purple },
          ].map(a => (
            <div key={a.ao} style={{ background:S.card, border:`1px solid ${a.col}44`, borderRadius:10, padding:16 }}>
              <div style={{ fontSize:16, fontWeight:700, color:a.col, fontFamily:"system-ui", marginBottom:4 }}>{a.ao}</div>
              <div style={{ fontSize:13, fontWeight:600, color:S.cream, marginBottom:6 }}>{a.name}</div>
              <div style={{ fontSize:11, color:S.muted, lineHeight:1.6, fontFamily:"system-ui" }}>{a.desc}</div>
            </div>
          ))}
        </div>

        <div style={{ textAlign:"center", paddingBottom:8 }}>
          <button onClick={onNext} style={{ background:`linear-gradient(135deg,${S.gold},#9A7A2D)`, color:"#000", border:"none", borderRadius:10, padding:"16px 56px", fontSize:17, fontWeight:700, cursor:"pointer", fontFamily:"system-ui", boxShadow:`0 4px 20px ${S.gold}44` }}>
            Begin Mock Examination →
          </button>
          <div style={{ fontFamily:"system-ui", fontSize:13, color:S.muted, marginTop:12 }}>
            Paper 1 · 11 questions · 60 marks · 90 minutes · AI-marked to Cambridge standard
          </div>
        </div>
      </div>
    </div>
  );
}

// ══════════════════ INSTRUCTIONS ════════════════════
function Instructions({ onBegin, onBack }) {
  return (
    <div style={{ minHeight:"100vh", background:S.examBg, fontFamily:"Georgia,'Times New Roman',serif" }}>
      <div style={{ maxWidth:740, margin:"0 auto", padding:"40px 24px" }}>
        <div style={{ border:"2px solid #1A1F2E", padding:"20px 28px", marginBottom:28 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div>
              <div style={{ fontFamily:"system-ui", fontSize:10, letterSpacing:2, color:"#666", marginBottom:4 }}>CAMBRIDGE INTERNATIONAL AS & A LEVEL</div>
              <div style={{ fontWeight:700, fontSize:22, color:S.examText }}>PSYCHOLOGY 9990/11</div>
              <div style={{ fontSize:14, color:"#444", marginTop:4 }}>Paper 1 – Approaches, Issues and Debates</div>
            </div>
            <div style={{ textAlign:"right", fontFamily:"system-ui" }}>
              <div style={{ fontSize:11, color:"#666" }}>Mock Examination 2026</div>
              <div style={{ fontWeight:700, fontSize:15, marginTop:4 }}>1 hour 30 minutes</div>
            </div>
          </div>
          <div style={{ borderTop:"1px solid #AAA", paddingTop:16, marginTop:16 }}>
            <div style={{ fontFamily:"system-ui", fontWeight:700, fontSize:13, marginBottom:10 }}>INSTRUCTIONS TO CANDIDATES</div>
            {["Answer all questions in Section A and Section B.",
              "The number of marks is given in brackets [ ] at the end of each question.",
              "For extended response questions (6+ marks), plan your answer before writing.",
              "The total number of marks for this paper is 60."
            ].map((t,i) => <div key={i} style={{ display:"flex", gap:8, marginBottom:6, fontFamily:"system-ui", fontSize:13 }}><span>•</span><span>{t}</span></div>)}
          </div>
        </div>

        <div style={{ background:"#FFF7ED", border:"1px solid #FDBA74", borderRadius:10, padding:18, marginBottom:18, display:"flex", gap:14 }}>
          <span style={{ fontSize:26, flexShrink:0 }}>⏱️</span>
          <div style={{ fontFamily:"system-ui" }}>
            <div style={{ fontWeight:700, color:"#9A3412", marginBottom:4 }}>Real-Time 90 Minute Timer</div>
            <div style={{ fontSize:13, color:"#7C2D12", lineHeight:1.6 }}>Timer starts immediately and cannot be paused. Turns <strong>orange</strong> at 45 min, <strong>red</strong> at 18 min. Auto-submits at 0:00.</div>
          </div>
        </div>

        <div style={{ background:"#F0FDF4", border:"1px solid #86EFAC", borderRadius:10, padding:18, marginBottom:32, display:"flex", gap:14 }}>
          <span style={{ fontSize:26, flexShrink:0 }}>🤖</span>
          <div style={{ fontFamily:"system-ui" }}>
            <div style={{ fontWeight:700, color:"#166534", marginBottom:4 }}>AI-Powered Cambridge Marking</div>
            <div style={{ fontSize:13, color:"#14532D", lineHeight:1.6 }}>After submission your paper is marked using AO1/AO2/AO3 and level-based Cambridge criteria. You receive marks per question, model answers, grade, and personalised feedback.</div>
          </div>
        </div>

        <div style={{ display:"flex", gap:12, justifyContent:"center" }}>
          <button onClick={onBack} style={{ background:"transparent", color:S.examText, border:"2px solid #AAA", borderRadius:8, padding:"12px 24px", cursor:"pointer", fontFamily:"system-ui", fontWeight:600 }}>← Back</button>
          <button onClick={onBegin} style={{ background:"#1A3254", color:"#FFF", border:"none", borderRadius:8, padding:"14px 48px", cursor:"pointer", fontFamily:"system-ui", fontWeight:700, fontSize:16 }}>
            ▶ Start Examination – 90:00
          </button>
        </div>
      </div>
    </div>
  );
}

// ══════════════════ QUESTION BLOCK ══════════════════
function QBlock({ q, val, onChange, divider }) {
  const rows = q.pts >= 10 ? 18 : q.pts >= 6 ? 12 : q.pts >= 4 ? 8 : 4;
  const done = val.trim().length > 0;
  return (
    <div style={{ marginBottom:divider?32:0, paddingBottom:divider?28:0, borderBottom:divider?"1px dashed #C9B99A":"none" }}>
      <div style={{ display:"flex", gap:12, alignItems:"flex-start", marginBottom:10 }}>
        <div style={{ width:30, height:30, borderRadius:"50%", background:done?"#10B981":"#1A3254", color:"#FFF", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"system-ui", fontSize:13, fontWeight:700, flexShrink:0, marginTop:2 }}>{q.n}</div>
        <div style={{ flex:1, fontSize:15, lineHeight:1.65 }}>
          <span style={{ fontFamily:"system-ui", fontWeight:700, color:"#1A3254" }}>({String.fromCharCode(96+q.n)}) </span>{q.q}
        </div>
        <div style={{ background:"#1A3254", color:"#FFF", borderRadius:6, padding:"4px 12px", fontFamily:"system-ui", fontSize:14, fontWeight:700, flexShrink:0 }}>[{q.pts}]</div>
      </div>
      <div style={{ marginLeft:42 }}>
        <div style={{ fontFamily:"system-ui", fontSize:11, color:"#888", marginBottom:6, lineHeight:1.5 }}>📎 {q.hint}</div>
        <textarea value={val} onChange={e => onChange(e.target.value)} placeholder={q.ph} rows={rows}
          style={{ width:"100%", boxSizing:"border-box", border:`2px solid ${done?"#10B981":S.examBorder}`, borderRadius:8, padding:"10px 14px", fontFamily:"Georgia,serif", fontSize:14, lineHeight:1.7, color:S.examText, background:"#FFFDF7", resize:"vertical", outline:"none", transition:"border-color 0.2s" }} />
      </div>
    </div>
  );
}

// ══════════════════ EXAM PAGE ═══════════════════════
function Exam({ questions, answers, onAnswer, timeLeft, timerColor, fmtTime, onSubmit }) {
  const [modal, setModal] = useState(false);
  const answered = Object.keys(answers).filter(k => (answers[k]||"").trim().length > 0).length;
  const pulse = timeLeft < 300;
  const secA = questions.filter(q => q.sec === "A");
  const secB = questions.filter(q => q.sec === "B");

  return (
    <div style={{ minHeight:"100vh", background:S.examBg, color:S.examText, fontFamily:"Georgia,'Times New Roman',serif" }}>
      <div style={{ position:"fixed", top:0, left:0, right:0, zIndex:100, background:"#FFFEF8", borderBottom:`2px solid ${S.examBorder}`, padding:"10px 24px", display:"flex", justifyContent:"space-between", alignItems:"center", boxShadow:"0 2px 10px rgba(0,0,0,0.08)" }}>
        <div style={{ fontFamily:"system-ui", fontSize:14 }}>
          <span style={{ fontWeight:700 }}>Psychology 9990/11</span>
          <span style={{ background:"#1A3254", color:"#FFF", fontSize:10, padding:"2px 10px", borderRadius:4, marginLeft:10, fontWeight:700 }}>MOCK</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:20 }}>
          <span style={{ fontFamily:"system-ui", fontSize:13, color:"#666" }}>{answered}/{questions.length} answered</span>
          <div style={{ border:`2px solid ${timerColor}`, borderRadius:8, padding:"6px 16px", background:pulse?timerColor+"15":"transparent", animation:pulse?"blink 1s infinite":"none" }}>
            <span style={{ fontFamily:"'Courier New',monospace", fontSize:22, fontWeight:700, color:timerColor, letterSpacing:2 }}>{fmtTime(timeLeft)}</span>
          </div>
          <button onClick={() => setModal(true)} style={{ background:"#1A3254", color:"#FFF", border:"none", borderRadius:8, padding:"8px 20px", cursor:"pointer", fontFamily:"system-ui", fontWeight:600, fontSize:14 }}>Submit Paper</button>
        </div>
      </div>

      {modal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.55)", zIndex:200, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ background:"#FFF", borderRadius:16, padding:36, maxWidth:420, width:"90%", textAlign:"center", boxShadow:"0 20px 60px rgba(0,0,0,0.3)" }}>
            <div style={{ fontSize:44, marginBottom:14 }}>📤</div>
            <h3 style={{ margin:"0 0 10px", fontSize:20 }}>Submit your paper?</h3>
            <p style={{ color:"#555", fontFamily:"system-ui", fontSize:14, margin:"0 0 6px" }}>Answered: <strong>{answered}</strong> of <strong>{questions.length}</strong> · Time: <strong style={{ color:timerColor }}>{fmtTime(timeLeft)}</strong></p>
            {answered < questions.length && <p style={{ color:"#DC2626", fontFamily:"system-ui", fontSize:13, margin:"0 0 12px" }}>⚠️ {questions.length-answered} unanswered will score 0.</p>}
            <p style={{ color:"#888", fontFamily:"system-ui", fontSize:12, margin:"0 0 24px" }}>This action cannot be undone.</p>
            <div style={{ display:"flex", gap:12, justifyContent:"center" }}>
              <button onClick={() => setModal(false)} style={{ background:"#F4F4F4", color:"#333", border:"1px solid #DDD", borderRadius:8, padding:"10px 22px", cursor:"pointer", fontFamily:"system-ui", fontWeight:600 }}>Continue Writing</button>
              <button onClick={onSubmit} style={{ background:"#1A3254", color:"#FFF", border:"none", borderRadius:8, padding:"10px 28px", cursor:"pointer", fontFamily:"system-ui", fontWeight:700 }}>Submit Now</button>
            </div>
          </div>
        </div>
      )}

      <div style={{ maxWidth:760, margin:"0 auto", padding:"80px 24px 60px" }}>
        <div style={{ border:"2px solid #1A1F2E", padding:"18px 24px", marginBottom:32 }}>
          <div style={{ display:"flex", justifyContent:"space-between" }}>
            <div>
              <div style={{ fontFamily:"system-ui", fontSize:10, letterSpacing:2, color:"#888" }}>CAMBRIDGE INTERNATIONAL A LEVEL</div>
              <div style={{ fontWeight:700, fontSize:20 }}>PSYCHOLOGY 9990/11</div>
              <div style={{ fontSize:13, color:"#555" }}>Paper 1 – Approaches, Issues and Debates</div>
            </div>
            <div style={{ textAlign:"right", fontFamily:"system-ui", fontSize:13 }}>
              <div style={{ color:"#888" }}>Total: 60 marks</div>
              <div style={{ fontWeight:700, marginTop:4 }}>Answer all questions</div>
            </div>
          </div>
        </div>

        <div style={{ marginBottom:48 }}>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
            <span style={{ fontFamily:"system-ui", fontWeight:700, fontSize:16 }}>SECTION A</span>
            <span style={{ fontFamily:"system-ui", fontSize:13, color:"#666" }}>[38 marks] — Answer all questions</span>
          </div>
          <div style={{ borderTop:"2px solid #1A1F2E", paddingTop:24 }}>
            {secA.map((q,i) => <QBlock key={q.id} q={q} val={answers[q.id]||""} onChange={v => onAnswer(q.id,v)} divider={i<secA.length-1} />)}
          </div>
        </div>

        <div>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
            <span style={{ fontFamily:"system-ui", fontWeight:700, fontSize:16 }}>SECTION B</span>
            <span style={{ fontFamily:"system-ui", fontSize:13, color:"#666" }}>[22 marks] — Answer all questions</span>
          </div>
          <div style={{ borderTop:"2px solid #1A1F2E", paddingTop:24 }}>
            {secB.map((q,i) => <QBlock key={q.id} q={q} val={answers[q.id]||""} onChange={v => onAnswer(q.id,v)} divider={i<secB.length-1} />)}
          </div>
        </div>

        <div style={{ marginTop:48, textAlign:"center", borderTop:"2px solid #1A1F2E", paddingTop:28 }}>
          <div style={{ fontFamily:"system-ui", fontSize:13, color:"#888", marginBottom:14 }}>End of paper. Check your answers before submitting.</div>
          <button onClick={() => setModal(true)} style={{ background:"#1A3254", color:"#FFF", border:"none", borderRadius:8, padding:"14px 48px", cursor:"pointer", fontFamily:"system-ui", fontWeight:700, fontSize:16 }}>Submit Paper for Marking</button>
        </div>
      </div>
      <style>{`@keyframes blink{0%,100%{opacity:1}50%{opacity:0.35}}`}</style>
    </div>
  );
}

// ══════════════════ MARKING PAGE ════════════════════
function Marking() {
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = setInterval(() => setTick(x => x+1), 700); return () => clearInterval(t); }, []);
  const steps = ["Reading your answers","Applying mark scheme criteria","Calculating marks per question","Writing examiner feedback & model answers"];
  const icons = ["📋","🔍","📊","✍️"];
  return (
    <div style={{ minHeight:"100vh", background:S.darkBg, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"system-ui" }}>
      <div style={{ textAlign:"center", color:S.cream, maxWidth:440, padding:32 }}>
        <div style={{ fontSize:56, marginBottom:24, display:"inline-block", animation:"spin 2s linear infinite" }}>⚖️</div>
        <h2 style={{ fontFamily:"Georgia,serif", fontSize:24, marginBottom:8 }}>Marking Your Paper...</h2>
        <p style={{ color:S.muted, fontSize:14, marginBottom:32 }}>Cambridge 9990 mark scheme · AO1 / AO2 / AO3 criteria</p>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {steps.map((s,i) => {
            const active = i === tick % (steps.length + 2);
            const done = i < tick % (steps.length + 2);
            return (
              <div key={i} style={{ display:"flex", gap:12, alignItems:"center", background:done||active?"#0D2040":S.card, border:`1px solid ${done||active?S.blue:S.border}`, borderRadius:8, padding:"12px 16px", textAlign:"left" }}>
                <span style={{ fontSize:18 }}>{icons[i]}</span>
                <span style={{ fontSize:13, color:done||active?S.cream:S.muted }}>{s}</span>
                <span style={{ marginLeft:"auto", color:done?S.green:active?S.orange:S.muted, fontWeight:700 }}>{done?"✓":active?"…":"–"}</span>
              </div>
            );
          })}
        </div>
        <p style={{ color:S.muted, fontSize:12, marginTop:24 }}>This may take 20–40 seconds. Please wait.</p>
      </div>
      <style>{`@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ══════════════════ RESULTS PAGE ════════════════════
function Results({ results, questions, answers, error, onRestart }) {
  const [open, setOpen] = useState(null);
  const GCOL = { A:"#10B981", B:"#3B82F6", C:"#F59E0B", D:"#F97316", E:"#EF4444", U:"#6B7280" };

  if (!results || error) return (
    <div style={{ minHeight:"100vh", background:S.darkBg, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"system-ui" }}>
      <div style={{ textAlign:"center", color:S.cream, padding:32, maxWidth:420 }}>
        <div style={{ fontSize:48, marginBottom:16 }}>⚠️</div>
        <h2 style={{ fontFamily:"Georgia,serif" }}>Marking Error</h2>
        <p style={{ color:S.muted, marginBottom:20 }}>Could not complete marking. Check your connection.</p>
        {error && <code style={{ display:"block", background:"#0A0A0A", color:"#F87171", padding:"8px 12px", borderRadius:6, fontSize:11, wordBreak:"break-all", marginBottom:24 }}>{error}</code>}
        <button onClick={onRestart} style={{ background:S.gold, color:"#000", border:"none", borderRadius:8, padding:"12px 32px", cursor:"pointer", fontWeight:700, fontFamily:"system-ui" }}>← Try Again</button>
      </div>
    </div>
  );

  const gCol = GCOL[results.grade] || S.muted;
  const pct = Math.round((results.totalMarks / 60) * 100);

  return (
    <div style={{ minHeight:"100vh", background:S.darkBg, color:S.cream, fontFamily:"system-ui" }}>
      <div style={{ background:"linear-gradient(135deg,#0D1F3C,#18083C)", padding:"40px 32px 32px", borderBottom:`1px solid ${S.border}` }}>
        <div style={{ maxWidth:860, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"auto 1fr auto", gap:28, alignItems:"center" }}>
            <div style={{ textAlign:"center" }}>
              <div style={{ width:90, height:90, borderRadius:"50%", background:gCol+"22", border:`3px solid ${gCol}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
                <span style={{ fontFamily:"Georgia,serif", fontSize:38, fontWeight:700, color:gCol, lineHeight:1 }}>{results.grade}</span>
              </div>
              <div style={{ fontSize:11, color:S.muted, marginTop:8 }}>Cambridge Grade</div>
            </div>
            <div>
              <div style={{ fontSize:40, fontWeight:700, fontFamily:"Georgia,serif" }}>{results.totalMarks}<span style={{ fontSize:22, color:S.muted }}>/60</span></div>
              <div style={{ fontSize:16, color:gCol, fontWeight:600, marginBottom:8 }}>{results.gradeLabel}</div>
              <p style={{ color:S.muted, fontSize:13, margin:0, lineHeight:1.6, maxWidth:480 }}>{results.overallComment}</p>
            </div>
            <div style={{ textAlign:"center" }}>
              <div style={{ fontSize:30, fontWeight:700, color:S.gold }}>{pct}%</div>
              <div style={{ fontSize:11, color:S.muted, marginBottom:10 }}>Score</div>
              <div style={{ background:"#1A3254", borderRadius:6, height:8, width:90 }}>
                <div style={{ width:`${pct}%`, height:"100%", background:gCol, borderRadius:6 }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:860, margin:"0 auto", padding:"28px 24px" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:24 }}>
          <div style={{ background:S.card, border:`1px solid ${S.border}`, borderRadius:12, padding:18 }}>
            <div style={{ fontSize:11, color:S.green, fontWeight:700, letterSpacing:1, marginBottom:10 }}>✓ STRENGTHS</div>
            {(results.strengths||[]).map((s,i) => <div key={i} style={{ fontSize:13, color:S.cream, marginBottom:8, paddingLeft:10, borderLeft:`2px solid ${S.green}`, lineHeight:1.5 }}>{s}</div>)}
          </div>
          <div style={{ background:S.card, border:`1px solid ${S.border}`, borderRadius:12, padding:18 }}>
            <div style={{ fontSize:11, color:S.orange, fontWeight:700, letterSpacing:1, marginBottom:10 }}>↑ AREAS TO IMPROVE</div>
            {(results.areasToImprove||[]).map((a,i) => <div key={i} style={{ fontSize:13, color:S.cream, marginBottom:8, paddingLeft:10, borderLeft:`2px solid ${S.orange}`, lineHeight:1.5 }}>{a}</div>)}
          </div>
        </div>

        {results.examTip && (
          <div style={{ background:"#1A2840", border:`1px solid ${S.gold}`, borderRadius:10, padding:"14px 18px", marginBottom:24, display:"flex", gap:12 }}>
            <span style={{ fontSize:20 }}>🎯</span>
            <div>
              <div style={{ color:S.gold, fontWeight:700, fontSize:11, letterSpacing:1, marginBottom:4 }}>KEY EXAMINER TIP</div>
              <div style={{ fontSize:13, color:S.cream, lineHeight:1.6 }}>{results.examTip}</div>
            </div>
          </div>
        )}

        <div style={{ fontSize:14, fontWeight:700, color:S.gold, letterSpacing:0.5, marginBottom:14 }}>QUESTION-BY-QUESTION BREAKDOWN</div>
        <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:32 }}>
          {(results.questions||[]).map((r,i) => {
            const q = questions.find(qq => qq.id === r.id) || {};
            const pq = Math.round((r.marksGiven / (r.maxMarks||1)) * 100);
            const bc = pq >= 70 ? S.green : pq >= 40 ? S.orange : S.red;
            const isOpen = open === r.id;
            return (
              <div key={r.id} style={{ background:S.card, border:`1px solid ${isOpen?bc:S.border}`, borderRadius:12, overflow:"hidden" }}>
                <div onClick={() => setOpen(isOpen ? null : r.id)} style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 18px", cursor:"pointer" }}>
                  <div style={{ width:46, height:46, borderRadius:"50%", background:bc+"22", border:`2px solid ${bc}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <span style={{ fontSize:14, fontWeight:700, color:bc, lineHeight:1 }}>{r.marksGiven}</span>
                    <span style={{ fontSize:10, color:S.muted }}>/{r.maxMarks}</span>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:600, marginBottom:6 }}>Q{q.n||(i+1)}: <span style={{ fontFamily:"Georgia,serif", fontStyle:"italic", fontWeight:400, color:S.muted }}>{q.study||r.id}</span></div>
                    <div style={{ background:"#1A3254", borderRadius:3, height:5 }}>
                      <div style={{ width:`${pq}%`, height:"100%", background:bc, borderRadius:3 }} />
                    </div>
                  </div>
                  <div style={{ textAlign:"right", flexShrink:0, marginRight:8 }}>
                    <div style={{ fontSize:18, fontWeight:700, color:bc }}>{pq}%</div>
                    <div style={{ fontSize:10, color:S.muted }}>{r.aoBreakdown}</div>
                  </div>
                  <span style={{ color:S.muted, fontSize:14 }}>{isOpen?"▲":"▼"}</span>
                </div>
                {isOpen && (
                  <div style={{ borderTop:`1px solid ${S.border}`, padding:"18px 22px" }}>
                    <div style={{ marginBottom:16 }}>
                      <div style={{ fontSize:10, color:S.muted, letterSpacing:1, marginBottom:6, fontWeight:700 }}>YOUR ANSWER</div>
                      <div style={{ background:"#0A1628", borderRadius:8, padding:"10px 14px", fontSize:13, color:"#A0B4CC", lineHeight:1.7, whiteSpace:"pre-wrap", maxHeight:160, overflow:"auto", fontFamily:"Georgia,serif" }}>
                        {(answers[r.id]||"").trim() || <em style={{ color:S.red }}>No answer provided</em>}
                      </div>
                    </div>
                    <div style={{ marginBottom:14 }}>
                      <div style={{ fontSize:10, color:S.green, letterSpacing:1, marginBottom:6, fontWeight:700 }}>✓ WHAT EARNED MARKS</div>
                      <div style={{ fontSize:13, color:S.cream, lineHeight:1.6, paddingLeft:12, borderLeft:`2px solid ${S.green}` }}>{r.whatWorked||"—"}</div>
                    </div>
                    <div style={{ marginBottom:14 }}>
                      <div style={{ fontSize:10, color:S.orange, letterSpacing:1, marginBottom:6, fontWeight:700 }}>↑ GAPS — WHAT WAS MISSING</div>
                      <div style={{ fontSize:13, color:S.cream, lineHeight:1.6, paddingLeft:12, borderLeft:`2px solid ${S.orange}` }}>{r.gaps||"—"}</div>
                    </div>
                    <div style={{ marginBottom:14 }}>
                      <div style={{ fontSize:10, color:S.blue, letterSpacing:1, marginBottom:6, fontWeight:700 }}>📋 MODEL ANSWER / KEY POINTS FOR FULL MARKS</div>
                      <div style={{ background:"#0A1820", borderRadius:8, padding:"12px 14px", fontSize:13, color:"#93C5FD", lineHeight:1.7, whiteSpace:"pre-wrap", fontFamily:"Georgia,serif" }}>{r.modelAnswer||"—"}</div>
                    </div>
                    {r.tip && <div style={{ background:"#131528", borderRadius:8, padding:"10px 14px", display:"flex", gap:8 }}>
                      <span>🎯</span><div style={{ fontSize:12, color:S.muted, lineHeight:1.6 }}><strong style={{ color:S.gold }}>Examiner tip:</strong> {r.tip}</div>
                    </div>}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div style={{ background:S.card, border:`1px solid ${S.border}`, borderRadius:12, padding:20, marginBottom:32 }}>
          <div style={{ fontSize:11, color:S.gold, fontWeight:700, letterSpacing:1, marginBottom:14 }}>GRADE BOUNDARIES — CAMBRIDGE 9990/11</div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            {[["A","45+","#10B981"],["B","38–44","#3B82F6"],["C","31–37","#F59E0B"],["D","24–30","#F97316"],["E","17–23","#EF4444"],["U","0–16","#6B7280"]].map(([g,r,c]) => (
              <div key={g} style={{ background:results.grade===g?c+"33":"transparent", border:`1px solid ${results.grade===g?c:S.border}`, borderRadius:8, padding:"8px 16px", textAlign:"center", minWidth:70 }}>
                <div style={{ fontFamily:"Georgia,serif", fontSize:18, fontWeight:700, color:results.grade===g?c:S.muted }}>{g}</div>
                <div style={{ fontSize:11, color:S.muted }}>{r}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign:"center" }}>
          <button onClick={onRestart} style={{ background:S.gold, color:"#000", border:"none", borderRadius:10, padding:"14px 44px", cursor:"pointer", fontWeight:700, fontSize:16, fontFamily:"system-ui" }}>← Return to Topic Research</button>
        </div>
      </div>
    </div>
  );
}

// ══════════════════ MAIN APP ═════════════════════════
export default function PsychMock() {
  const [unlocked, setUnlocked] = useState(false);
  const [phase, setPhase] = useState("research");
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(EXAM_SECS);
  const [timerActive, setTimerActive] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const timerRef = useRef(null);
  const autoSub = useRef(false);
  const answersRef = useRef(answers);

  useEffect(() => { answersRef.current = answers; }, [answers]);

  useEffect(() => {
    if (!timerActive) return;
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) { clearInterval(timerRef.current); autoSub.current = true; return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [timerActive]);

  useEffect(() => {
    if (timeLeft === 0 && autoSub.current) { autoSub.current = false; doSubmit(answersRef.current); }
  }, [timeLeft]);

  const fmtTime = s => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;
  const timerColor = timeLeft > EXAM_SECS*0.5 ? "#10B981" : timeLeft > EXAM_SECS*0.2 ? "#F59E0B" : "#EF4444";

  const startExam = () => { setTimerActive(true); setPhase("exam"); };

  const doSubmit = async (currentAnswers) => {
    clearInterval(timerRef.current);
    setTimerActive(false);
    setPhase("marking");
    setError(null);
    try {
      // Calls our Netlify Function — API key never leaves the server
      const res = await fetch("/.netlify/functions/mark", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 4000, messages: [{ role: "user", content: buildPrompt(currentAnswers) }] })
      });
      if (!res.ok) throw new Error(`Server returned HTTP ${res.status}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
      const rawText = (data.content||[]).filter(b => b.type==="text").map(b => b.text).join("");
      const clean = rawText.replace(/```json\s*/gi,"").replace(/```\s*/gi,"").trim();
      setResults(JSON.parse(clean));
    } catch(e) {
      setError(e.message);
    } finally {
      setPhase("results");
    }
  };

  const restart = () => {
    clearInterval(timerRef.current);
    setAnswers({}); setTimeLeft(EXAM_SECS); setTimerActive(false);
    setResults(null); setError(null); setPhase("research");
  };

  if (!unlocked) return <AccessGate onUnlock={() => setUnlocked(true)} />;
  if (phase==="research")    return <Research onNext={() => setPhase("instructions")} />;
  if (phase==="instructions") return <Instructions onBegin={startExam} onBack={() => setPhase("research")} />;
  if (phase==="exam")        return <Exam questions={QUESTIONS} answers={answers} onAnswer={(id,v)=>setAnswers(p=>({...p,[id]:v}))} timeLeft={timeLeft} timerColor={timerColor} fmtTime={fmtTime} onSubmit={() => doSubmit(answers)} />;
  if (phase==="marking")     return <Marking />;
  if (phase==="results")     return <Results results={results} questions={QUESTIONS} answers={answers} error={error} onRestart={restart} />;
}
